package ru.cosmos;

import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;

public class CosmosPlugin extends JavaPlugin implements TabExecutor {

    private CosmosShow current;

    @Override
    public void onEnable() {
        var cmd = getCommand("cosmos");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
        getLogger().info("CosmosShow enabled.");
    }

    @Override
    public void onDisable() {
        if (current != null) {
            current.cancel();
            current = null;
        }
    }

    void clear(CosmosShow show) {
        if (current == show) current = null;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String sub = args.length > 0 ? args[0].toLowerCase() : "start";

        if (sub.equals("stop")) {
            if (current == null) {
                sender.sendMessage("Шоу сейчас не запущено.");
            } else {
                current.cancel();
                current = null;
                sender.sendMessage("Шоу остановлено.");
            }
            return true;
        }

        if (!sub.equals("start")) {
            sender.sendMessage("Использование: /cosmos <start|stop> [масштаб] [плотность]");
            return true;
        }

        if (!(sender instanceof Player player)) {
            sender.sendMessage("Запускать шоу может только игрок.");
            return true;
        }
        if (current != null) {
            sender.sendMessage("Шоу уже идёт. Остановить: /cosmos stop");
            return true;
        }

        double scale = 1.0;
        double density = 1.0;
        try {
            if (args.length > 1) scale = Double.parseDouble(args[1]);
            if (args.length > 2) density = Double.parseDouble(args[2]);
        } catch (NumberFormatException e) {
            sender.sendMessage("Масштаб и плотность должны быть числами.");
            return true;
        }
        scale = Math.max(0.3, Math.min(4.0, scale));
        density = Math.max(0.15, Math.min(2.5, density));

        Location loc = player.getLocation();
        Vector dir = loc.getDirection();
        dir.setY(0);
        if (dir.lengthSquared() < 1.0e-6) dir = new Vector(0, 0, 1);
        dir.normalize();

        Location center = new Location(
                loc.getWorld(),
                loc.getX() + dir.getX() * 60 * scale,
                loc.getY() + 75 * scale,
                loc.getZ() + dir.getZ() * 60 * scale);

        current = new CosmosShow(this, center, scale, density);
        current.runTaskTimer(this, 20L, 1L);
        sender.sendMessage("Космическое шоу начнётся через секунду. Длительность ~115 сек. Смотри вверх!");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            out.add("start");
            out.add("stop");
        } else if (args.length == 2) {
            out.add("1.0");
            out.add("2.0");
        } else if (args.length == 3) {
            out.add("1.0");
            out.add("0.5");
        }
        return out;
    }
}
