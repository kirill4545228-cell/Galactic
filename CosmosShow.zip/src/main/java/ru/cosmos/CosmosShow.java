package ru.cosmos;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * ~115 second cosmic show (2300 ticks):
 * galaxy birth -> living galaxy -> collapse -> supernova -> black hole -> quasar -> hypernova finale -> rebirth.
 */
public class CosmosShow extends BukkitRunnable {

    public static final int TOTAL = 2300;

    private static final double GAL_TX = 0.45;
    private static final double GAL_TZ = 0.15;

    private final CosmosPlugin plugin;
    private final World w;
    private final Location center;
    private final double cx, cy, cz;
    private final double S;
    private final double R;
    private final double density;
    private final Random rnd = new Random();

    private int t = 0;
    private double rot = 0;
    private double tx = 0.35, tz = 0.1;
    private double fade = 1.0;

    private final List<Wave> waves = new ArrayList<>();
    private final List<Burst> bursts = new ArrayList<>();

    private static class Wave {
        int start;
        double speed, maxR, tx, tz, hue, span;
    }

    private static class Burst {
        int start;
        double x, y, z, speed, maxR, hue;
    }

    public CosmosShow(CosmosPlugin plugin, Location center, double scale, double density) {
        this.plugin = plugin;
        this.center = center;
        this.w = center.getWorld();
        this.cx = center.getX();
        this.cy = center.getY();
        this.cz = center.getZ();
        this.S = scale;
        this.R = 45.0 * scale;
        this.density = density;
    }

    // ------------------------------------------------------------------ main loop

    @Override
    public void run() {
        try {
            tick();
        } catch (Throwable ex) {
            plugin.getLogger().warning("CosmosShow error: " + ex);
            ex.printStackTrace();
            finish();
        }
    }

    private void tick() {
        if (t >= TOTAL) {
            finish();
            return;
        }
        fade = t > TOTAL - 120 ? Math.max(0.0, (TOTAL - t) / 120.0) : 1.0;

        announce();

        if (t < 200) phaseBirth();
        else if (t < 500) phaseGalaxy();
        else if (t < 620) phaseCollapse();
        else if (t < 900) phaseSupernova();
        else if (t < 1300) phaseBlackHole();
        else if (t < 1700) phaseQuasar();
        else if (t < 1950) phaseFinale();
        else phaseRebirth();

        updateWaves();
        updateBursts();
        t++;
    }

    private void finish() {
        cancel();
        plugin.clear(this);
        sound(Sound.UI_TOAST_CHALLENGE_COMPLETE, 100f, 0.8f);
        title("Конец", "Вселенная родится снова", NamedTextColor.WHITE);
    }

    // ------------------------------------------------------------------ phases

    private void phaseBirth() {
        double p = t / 200.0;
        double e = smooth(p);
        rot += 0.012;
        galaxy(R * e, n((int) (150 + 250 * p)), 1.0, 0.0);
        corePulse(R * 0.03 * e, n(10));
        dustField(n(20));
        if (t == 0) sound(Sound.BLOCK_BEACON_ACTIVATE, 100f, 0.5f);
        if (t == 100) sound(Sound.ENTITY_ENDER_DRAGON_GROWL, 150f, 0.5f);
    }

    private void phaseGalaxy() {
        double q = (t - 200) / 300.0;
        rot += 0.014;
        galaxy(R, n(430), 1.0, 0.0);
        corePulse(R * (0.04 + 0.05 * q), n(25));
        dustField(n(30));
        if (t % 50 == 0) addWave(1.1 * S, R * 1.6, GAL_TX, GAL_TZ, rnd.nextDouble(), 0.3);
        if (t % 30 == 0) addBurst(randInside(R * 0.9), 0.5 * S, 9 * S, rnd.nextDouble());
        if (t == 200) sound(Sound.BLOCK_BEACON_POWER_SELECT, 100f, 0.6f);
        if (t == 350) sound(Sound.ENTITY_ENDER_DRAGON_GROWL, 150f, 0.4f);
    }

    private void phaseCollapse() {
        double q = (t - 500) / 120.0;
        double e = smooth(q);
        rot += 0.014 + 0.30 * q * q;
        galaxy(R * (1 - 0.88 * e), n(450), 1.0 - 0.25 * q, -0.06 * q);
        double cr = R * (0.09 - 0.07 * e);
        corePulse(cr, n(45));
        for (int i = 0; i < n(40); i++) {
            Vector d = randDir();
            Vector pos = d.clone().multiply(R * (0.5 + rnd.nextDouble() * 0.7));
            vel(Particle.END_ROD, pos, d.clone().multiply(-1), 2.5);
        }
        if (t == 500) sound(Sound.ENTITY_WARDEN_SONIC_CHARGE, 150f, 0.5f);
        if (t == 560) sound(Sound.BLOCK_BEACON_DEACTIVATE, 150f, 0.5f);
    }

    private void phaseSupernova() {
        int dt = t - 620;
        if (dt == 0) supernovaFlash();

        double pr = dt / 280.0;
        double r = 2.1 * R * (1 - Math.exp(-3.0 * pr));
        double hue = 0.15 - pr * 0.2;
        shell(0, 0, 0, r, 260, hue, 0.15 + 0.7 * pr, 1.0, 2.3f, rot * 0.3, 0.15);
        shell(0, 0, 0, r * 0.7, 180, hue + 0.55, 0.6, 1.0, 2.0f, -rot * 0.2, 0.2);
        for (int i = 0; i < n(40); i++) {
            Vector v = randDir().multiply(r * rnd.nextDouble());
            emit(Particle.ELECTRIC_SPARK, v.getX(), v.getY(), v.getZ(), 1, 0, 0, 0, 0.05);
        }
        if (dt % 12 == 0) addBurst(randInside(r * 0.9), 0.8 * S, 12 * S + R * 0.2, rnd.nextDouble());
        if (dt % 70 == 35) sound(Sound.ENTITY_FIREWORK_ROCKET_LARGE_BLAST, 120f, 0.7f);
        rot += 0.02;
    }

    private void supernovaFlash() {
        sound(Sound.ENTITY_GENERIC_EXPLODE, 250f, 0.5f);
        sound(Sound.ENTITY_ENDER_DRAGON_DEATH, 200f, 0.6f);
        for (int i = 0; i < 20; i++) {
            Vector v = randInside(R * 0.15);
            emit(Particle.EXPLOSION_EMITTER, v.getX(), v.getY(), v.getZ(), 1, 0, 0, 0, 0);
        }
        for (int i = 0; i < n(900); i++) {
            Particle p = switch (i % 3) {
                case 0 -> Particle.FIREWORK;
                case 1 -> Particle.END_ROD;
                default -> Particle.FLAME;
            };
            vel(p, new Vector(0, 0, 0), randDir(), 0.5 + rnd.nextDouble() * 2.5);
        }
        addWave(1.6 * S, R * 3, GAL_TX, GAL_TZ, 0.08, 0.1);
        addWave(1.3 * S, R * 3, Math.PI / 2, 0, 0.0, 0.1);
        addWave(1.3 * S, R * 3, 0, Math.PI / 2, 0.6, 0.1);
    }

    private void phaseBlackHole() {
        double q = (t - 900) / 400.0;
        rot += 0.05;
        tx = 0.35 + 0.1 * Math.sin(t * 0.02);
        tz = 0.1;
        double rs = R * 0.11 * smooth((t - 900) / 100.0);
        blackHole(rs, R * (0.25 + 0.6 * smooth(q)), 1.0);
        dustField(n(15));
        if (t == 900) {
            sound(Sound.ENTITY_WITHER_SPAWN, 200f, 0.5f);
            addWave(1.5 * S, R * 2.2, 0, 0, 0.75, 0.2);
        }
        if (t == 1050) sound(Sound.ENTITY_ENDER_DRAGON_GROWL, 200f, 0.3f);
        if (t % 80 == 0 && t > 900) addWave(1.0 * S, R * 1.5, tx, tz, 0.05, 0.1);
        if (t == 1200) sound(Sound.ENTITY_WARDEN_SONIC_CHARGE, 200f, 0.4f);
    }

    private void phaseQuasar() {
        int dt = t - 1300;
        rot += 0.07;
        tx = 0.5 + 0.35 * Math.sin(t * 0.012);
        tz = 0.4 * Math.cos(t * 0.008);
        double rs = R * 0.11 * (1 + 0.08 * Math.sin(t * 0.3));
        blackHole(rs, R * 0.9 * (1 + 0.1 * Math.sin(t * 0.05)), 1.0);
        double ramp = smooth(Math.min(1.0, dt / 120.0));
        jets(rs, R * 3.2 * ramp);
        if (dt % 8 == 0) arc(rs * 1.5, R * (0.6 + rnd.nextDouble() * 0.9));
        if (dt % 8 == 4) arc(rs * 1.5, R * (0.6 + rnd.nextDouble() * 0.9));
        if (dt % 60 == 0) addWave(1.2 * S, R * 1.8, tx, tz, rnd.nextDouble(), 0.3);
        if (dt == 0) sound(Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 200f, 0.5f);
        if (dt == 40) sound(Sound.ENTITY_WARDEN_SONIC_BOOM, 200f, 0.5f);
        if (dt == 200) quasarFlare();
        if (dt % 100 == 50) sound(Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 150f, 0.7f);
    }

    private void quasarFlare() {
        sound(Sound.ENTITY_GENERIC_EXPLODE, 250f, 0.6f);
        sound(Sound.ENTITY_ENDER_DRAGON_GROWL, 250f, 0.4f);
        for (int s = -1; s <= 1; s += 2) {
            Vector axis = tf(new Vector(0, s, 0));
            for (int k = 1; k <= 6; k++) {
                Vector p = axis.clone().multiply(R * 0.5 * k);
                emit(Particle.EXPLOSION_EMITTER, p.getX(), p.getY(), p.getZ(), 1, 0, 0, 0, 0);
                addBurst(p, 1.2 * S, R * 1.2, k / 6.0);
            }
        }
        addWave(2.0 * S, R * 3, tx, tz, 0.55, 0.3);
        addWave(1.6 * S, R * 3, tx, tz, 0.9, 0.3);
    }

    private void phaseFinale() {
        int dt = t - 1700;
        if (dt < 60) {
            double q = dt / 60.0;
            rot += 0.1 + 0.5 * q;
            tx = 0.5 + 0.35 * Math.sin(t * 0.012);
            tz = 0.4 * Math.cos(t * 0.008);
            double rs = R * 0.11 * (1 + 0.3 * q);
            blackHole(rs, R * (0.9 - 0.7 * smooth(q)), 1.0);
            jets(rs, R * 3.2 * (1 - 0.5 * q));
            for (int i = 0; i < n(60); i++) {
                Vector d = randDir();
                vel(Particle.END_ROD, d.clone().multiply(R * (0.4 + rnd.nextDouble() * 0.6)), d.clone().multiply(-1), 3.0);
            }
            if (dt % 10 == 0) addWave(2.0 * S, R * 1.5, tx, tz, rnd.nextDouble(), 0.2);
            if (dt == 0) sound(Sound.ENTITY_WARDEN_SONIC_BOOM, 250f, 0.4f);
            if (dt == 30) sound(Sound.ENTITY_WARDEN_SONIC_CHARGE, 250f, 0.3f);
        } else {
            if (dt == 60) hypernova();
            double dd = dt - 60;
            double r = 3.2 * R * (1 - Math.exp(-2.5 * dd / 190.0));
            double h = dd * 0.004;
            shell(0, 0, 0, r, 380, h, 1.0, 1.0, 2.4f, rot * 0.1, 0.9);
            shell(0, 0, 0, r * 0.6, 260, h + 0.5, 1.0, 1.0, 2.2f, -rot * 0.1, 0.9);
            shell(0, 0, 0, r * 0.3, 160, h + 0.25, 0.5, 1.0, 2.0f, rot * 0.2, 0.9);
            if (dt % 6 == 0) addBurst(randInside(r * 0.9), 1.0 * S, 14 * S + R * 0.3, rnd.nextDouble());
            if (dt % 25 == 0) sound(Sound.ENTITY_FIREWORK_ROCKET_LARGE_BLAST, 150f, 0.6f);
            rot += 0.05;
        }
    }

    private void hypernova() {
        sound(Sound.ENTITY_GENERIC_EXPLODE, 300f, 0.4f);
        sound(Sound.ENTITY_ENDER_DRAGON_DEATH, 300f, 0.5f);
        sound(Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 300f, 0.5f);
        for (int i = 0; i < 40; i++) {
            Vector v = randInside(R * 0.6);
            emit(Particle.EXPLOSION_EMITTER, v.getX(), v.getY(), v.getZ(), 1, 0, 0, 0, 0);
        }
        Particle[] types = {Particle.FIREWORK, Particle.END_ROD, Particle.FLAME,
                Particle.SOUL_FIRE_FLAME, Particle.ELECTRIC_SPARK};
        for (int i = 0; i < n(1500); i++) {
            vel(types[i % types.length], new Vector(0, 0, 0), randDir(), 0.5 + rnd.nextDouble() * 4.0);
        }
        for (int k = 0; k < 6; k++) {
            addWave((1.5 + 0.3 * k) * S, R * 4, rnd.nextDouble() * Math.PI, rnd.nextDouble() * Math.PI, k / 6.0, 0.4);
        }
        for (int k = 0; k < 16; k++) {
            addBurst(new Vector(0, 0, 0), (1.0 + 0.15 * k) * S, R * 4, k / 16.0);
        }
    }

    private void phaseRebirth() {
        int dt = t - 1950;
        rot += 0.02;
        galaxy(R * 0.55 * smooth(Math.min(1.0, dt / 120.0)), n(260), 1.0, 0.12);
        corePulse(R * 0.05, n(15));
        helix(R * 1.2, R * 0.16, n(60));
        for (int i = 0; i < n(40); i++) {
            double a = rnd.nextDouble() * Math.PI * 2;
            double rad = Math.sqrt(rnd.nextDouble()) * R * 1.3;
            Vector pos = new Vector(Math.cos(a) * rad, R * 1.1 + rnd.nextDouble() * 5, Math.sin(a) * rad);
            vel(Particle.END_ROD, pos, new Vector(0, -1, 0), 0.25);
        }
        if (dt % 25 == 0) addBurst(randInside(R * 0.8), 0.4 * S, 8 * S, rnd.nextDouble());
        if (dt == 0) sound(Sound.BLOCK_BEACON_ACTIVATE, 200f, 0.6f);
        if (dt == 120) sound(Sound.BLOCK_BEACON_POWER_SELECT, 200f, 0.5f);
    }

    // ------------------------------------------------------------------ titles & sound

    private void announce() {
        switch (t) {
            case 0 -> title("Рождение галактики", "Из космической пыли зажигаются звёзды", NamedTextColor.AQUA);
            case 200 -> title("Звёздное ядро", "Галактика обретает жизнь", NamedTextColor.GOLD);
            case 500 -> title("Коллапс", "Звезда больше не выдерживает", NamedTextColor.RED);
            case 620 -> title("Сверхновая", "Взрыв, освещающий вселенную", NamedTextColor.YELLOW);
            case 900 -> title("Чёрная дыра", "Горизонт событий", NamedTextColor.DARK_PURPLE);
            case 1300 -> title("Квазар", "Самый яркий маяк космоса", NamedTextColor.LIGHT_PURPLE);
            case 1700 -> title("Гиперновая", "Конец и начало", NamedTextColor.WHITE);
            case 1950 -> title("Возрождение", "Новая галактика", NamedTextColor.GREEN);
            default -> {
            }
        }
    }

    private void title(String main, String sub, NamedTextColor color) {
        Title tt = Title.title(
                Component.text(main, color),
                Component.text(sub, NamedTextColor.GRAY),
                Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(3), Duration.ofMillis(800)));
        double lim = 700.0 * Math.max(1.0, S);
        for (Player pl : w.getPlayers()) {
            if (pl.getLocation().distanceSquared(center) < lim * lim) pl.showTitle(tt);
        }
    }

    private void sound(Sound s, float vol, float pitch) {
        w.playSound(center, s, SoundCategory.MASTER, vol, pitch);
    }

    // ------------------------------------------------------------------ structures

    private void galaxy(double radius, int count, double bright, double hueShift) {
        if (radius < 1) return;
        int arms = 4;
        for (int i = 0; i < count; i++) {
            double u = Math.pow(rnd.nextDouble(), 0.7);
            double r = u * radius;
            int arm = rnd.nextInt(arms);
            double ang = arm * 2 * Math.PI / arms + u * 3.8 + rot + rnd.nextGaussian() * (0.35 * (1 - u * 0.5));
            double thick = radius * 0.035 * (1 - u * 0.6);
            Vector v = new Vector(Math.cos(ang) * r, rnd.nextGaussian() * thick, Math.sin(ang) * r);
            v.rotateAroundX(GAL_TX).rotateAroundZ(GAL_TZ);
            double hue = hueShift + 0.09 + u * 0.62;
            double sat = Math.min(1.0, 0.35 + 0.65 * u);
            dust(v, hsv(hue, sat, bright), (float) (1.2 + rnd.nextDouble() * 1.6));
        }
    }

    private void corePulse(double radius, int count) {
        for (int i = 0; i < count; i++) {
            Vector v = randInside(radius);
            dust(v, hsv(0.1, 0.25 + rnd.nextDouble() * 0.2, 1.0), 2.6f);
            if (i % 3 == 0) emit(Particle.END_ROD, v.getX(), v.getY(), v.getZ(), 1, 0, 0, 0, 0.01);
        }
    }

    private void dustField(int count) {
        for (int i = 0; i < count; i++) {
            Vector v = randInside(R * 1.4);
            emit(Particle.END_ROD, v.getX(), v.getY(), v.getZ(), 1, 0, 0, 0, 0);
        }
    }

    private void blackHole(double rs, double rOut, double val) {
        if (rs < 0.5) return;
        for (int i = 0; i < n(140); i++) {
            dust(randDir().multiply(rs), Color.fromRGB(1, 1, 1), 3.5f);
        }
        double rIn = rs * 1.6;
        if (rOut < rIn + 1) rOut = rIn + 1;
        for (int i = 0; i < n(380); i++) {
            double f = Math.pow(rnd.nextDouble(), 1.6);
            double r = rIn + (rOut - rIn) * f;
            double a = rnd.nextDouble() * Math.PI * 2;
            Vector v = tf(new Vector(Math.cos(a) * r, rnd.nextGaussian() * rs * 0.04 * (0.3 + f), Math.sin(a) * r));
            dust(v, diskColor(f, val), (float) (1.5 + rnd.nextDouble() * 1.5));
        }
        for (int arm = 0; arm < 3; arm++) {
            for (int j = 0; j < n(45); j++) {
                double f = j / 45.0;
                double r = rIn + (rOut - rIn) * f;
                double a = arm * 2.0944 + (1 - f) * 6.0 - rot * 2.0;
                Vector v = tf(new Vector(Math.cos(a) * r, 0, Math.sin(a) * r));
                dust(v, diskColor(f, val), 2.3f);
            }
        }
        ring(rs * 1.45, 80, Math.PI / 2, 0, 0.12, 0.05, 1.6f, null);
        ring(rs * 1.45, 80, Math.PI / 2, Math.PI / 2, 0.12, 0.05, 1.6f, null);
        for (int i = 0; i < n(12); i++) {
            Vector d = randDir();
            Vector pos = d.clone().multiply(rOut * 1.1);
            vel(i % 2 == 0 ? Particle.END_ROD : Particle.REVERSE_PORTAL, pos, d.clone().multiply(-1), 0.5);
        }
    }

    private Color diskColor(double f, double val) {
        double hue = 0.6 - 0.62 * Math.sqrt(f);
        double sat = 0.15 + 0.85 * Math.min(1.0, f * 2.5);
        return hsv(hue, sat, val);
    }

    private void jets(double rs, double length) {
        if (length < 2) return;
        Vector u = tf(new Vector(1, 0, 0));
        Vector wv = tf(new Vector(0, 0, 1));
        for (int s = -1; s <= 1; s += 2) {
            Vector axis = tf(new Vector(0, s, 0));
            for (int i = 0; i < n(170); i++) {
                double h = Math.pow(rnd.nextDouble(), 1.3) * length;
                double spread = rs * 0.35 + h * 0.05;
                double a = h * 0.22 - rot * 2.5 + (i % 2) * Math.PI;
                double rad = spread * 0.7;
                Vector p = axis.clone().multiply(h)
                        .add(u.clone().multiply(Math.cos(a) * rad))
                        .add(wv.clone().multiply(Math.sin(a) * rad));
                double hue = 0.5 + 0.25 * Math.sin(h * 0.04 - t * 0.06);
                dust(p, hsv(hue, 0.7, 1.0), 2.0f);
            }
            for (int i = 0; i < n(25); i++) {
                Vector base = axis.clone().multiply(rs * 1.2);
                vel(Particle.END_ROD, base, axis, 0.9 + rnd.nextDouble() * 0.6);
            }
            Vector tip = axis.clone().multiply(length);
            emit(Particle.END_ROD, tip.getX(), tip.getY(), tip.getZ(), n(4), 1.5 * S, 1.5 * S, 1.5 * S, 0.02);
        }
    }

    private void arc(double r0, double r1) {
        Vector a = randDir().multiply(r0);
        Vector b = randDir().multiply(r1);
        int seg = 30;
        for (int i = 1; i <= seg; i++) {
            double f = i / (double) seg;
            Vector pt = a.clone().add(b.clone().subtract(a).multiply(f));
            if (i < seg) pt.add(randDir().multiply(R * 0.04));
            emit(Particle.ELECTRIC_SPARK, pt.getX(), pt.getY(), pt.getZ(), 2, 0.1, 0.1, 0.1, 0.01);
            if (i % 3 == 0) dust(pt, Color.fromRGB(220, 235, 255), 1.8f);
        }
    }

    private void helix(double height, double rad, int count) {
        for (int strand = 0; strand < 2; strand++) {
            for (int i = 0; i < count; i++) {
                double y = (rnd.nextDouble() * 2 - 1) * height;
                double a = y * 0.12 + rot * 2 + strand * Math.PI;
                dust(Math.cos(a) * rad, y, Math.sin(a) * rad,
                        hsv(y / height * 0.5 + t * 0.01, 0.8, 1.0), 2.0f);
            }
        }
    }

    private void ring(double r, int pts, double rtx, double rtz, double hue, double span, float size, Particle sparkle) {
        pts = Math.max(8, Math.min(420, (int) (pts * density * fade)));
        double off = rnd.nextDouble() * Math.PI * 2;
        for (int i = 0; i < pts; i++) {
            double a = off + i * 2 * Math.PI / pts;
            Vector v = new Vector(Math.cos(a) * r, 0, Math.sin(a) * r).rotateAroundX(rtx).rotateAroundZ(rtz);
            dust(v, hsv(hue + span * i / pts, 0.8, 1.0), size);
            if (sparkle != null && i % 7 == 0) emit(sparkle, v.getX(), v.getY(), v.getZ(), 1, 0, 0, 0, 0.02);
        }
    }

    private void shell(double ox, double oy, double oz, double r, int pts, double hue, double span,
                       double sat, float size, double twist, double val) {
        pts = Math.max(8, (int) (pts * density * fade));
        double ga = Math.PI * (3 - Math.sqrt(5));
        for (int i = 0; i < pts; i++) {
            double y = 1 - (i + 0.5) * 2.0 / pts;
            double rad = Math.sqrt(Math.max(0, 1 - y * y));
            double a = ga * i + twist;
            dust(ox + Math.cos(a) * rad * r, oy + y * r, oz + Math.sin(a) * rad * r,
                    hsv(hue + span * (y * 0.5 + 0.5), Math.min(1.0, sat), Math.min(1.0, val)), size);
        }
    }

    // ------------------------------------------------------------------ waves & bursts

    private void addWave(double speed, double maxR, double wtx, double wtz, double hue, double span) {
        Wave wv = new Wave();
        wv.start = t;
        wv.speed = speed;
        wv.maxR = maxR;
        wv.tx = wtx;
        wv.tz = wtz;
        wv.hue = hue;
        wv.span = span;
        waves.add(wv);
    }

    private void updateWaves() {
        Iterator<Wave> it = waves.iterator();
        while (it.hasNext()) {
            Wave wv = it.next();
            double r = (t - wv.start) * wv.speed;
            if (r > wv.maxR) {
                it.remove();
                continue;
            }
            if (r < 1) continue;
            ring(r, (int) (r * 3) + 16, wv.tx, wv.tz, wv.hue, wv.span, 2.0f, Particle.END_ROD);
        }
    }

    private void addBurst(Vector pos, double speed, double maxR, double hue) {
        Burst b = new Burst();
        b.start = t;
        b.x = pos.getX();
        b.y = pos.getY();
        b.z = pos.getZ();
        b.speed = speed;
        b.maxR = maxR;
        b.hue = hue;
        bursts.add(b);
    }

    private void updateBursts() {
        Iterator<Burst> it = bursts.iterator();
        while (it.hasNext()) {
            Burst b = it.next();
            double r = (t - b.start) * b.speed;
            if (r > b.maxR) {
                it.remove();
                continue;
            }
            if (r < 0.5) continue;
            int pts = (int) Math.min(500, 50 + r * 4);
            shell(b.x, b.y, b.z, r, pts, b.hue, 0.25, 0.9, 1.8f, t * 0.05, 1.0);
        }
    }

    // ------------------------------------------------------------------ helpers

    private void emit(Particle p, double x, double y, double z, int count,
                      double ox, double oy, double oz, double extra) {
        w.spawnParticle(p, cx + x, cy + y, cz + z, count, ox, oy, oz, extra, null, true);
    }

    private void dust(double x, double y, double z, Color c, float size) {
        w.spawnParticle(Particle.DUST, cx + x, cy + y, cz + z, 1, 0, 0, 0, 0,
                new Particle.DustOptions(c, size), true);
    }

    private void dust(Vector v, Color c, float size) {
        dust(v.getX(), v.getY(), v.getZ(), c, size);
    }

    /** Directional particle: count 0 means offset is the velocity direction, extra is speed. */
    private void vel(Particle p, Vector pos, Vector dir, double speed) {
        emit(p, pos.getX(), pos.getY(), pos.getZ(), 0, dir.getX(), dir.getY(), dir.getZ(), speed);
    }

    private Vector tf(Vector v) {
        return v.rotateAroundX(tx).rotateAroundZ(tz);
    }

    private Vector randDir() {
        double z = rnd.nextDouble() * 2 - 1;
        double a = rnd.nextDouble() * Math.PI * 2;
        double r = Math.sqrt(Math.max(0, 1 - z * z));
        return new Vector(r * Math.cos(a), z, r * Math.sin(a));
    }

    private Vector randInside(double radius) {
        return randDir().multiply(radius * Math.cbrt(rnd.nextDouble()));
    }

    private int n(int base) {
        return Math.max(0, (int) Math.round(base * density * fade));
    }

    private static double smooth(double x) {
        x = Math.max(0, Math.min(1, x));
        return x * x * (3 - 2 * x);
    }

    private static int c255(double v) {
        return (int) Math.max(0, Math.min(255, Math.round(v * 255)));
    }

    static Color hsv(double h, double s, double v) {
        h = h - Math.floor(h);
        double r, g, b;
        int i = (int) (h * 6);
        double f = h * 6 - i;
        double p = v * (1 - s);
        double q = v * (1 - f * s);
        double u = v * (1 - (1 - f) * s);
        switch (i % 6) {
            case 0 -> { r = v; g = u; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = u; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = u; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        return Color.fromRGB(c255(r), c255(g), c255(b));
    }
}
