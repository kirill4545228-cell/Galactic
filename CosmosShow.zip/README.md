# CosmosShow (Paper 1.21.11)
Команды: /cosmos start [масштаб] [плотность], /cosmos stop  (право cosmos.use, по умолчанию op)
Сборка: GitHub Actions -> Artifacts -> CosmosShow.jar -> в папку plugins/
